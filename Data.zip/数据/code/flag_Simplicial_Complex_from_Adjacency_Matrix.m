function stream = flag_Simplicial_Complex_from_Adjacency_Matrix(adjmat)

import edu.stanford.math.plex4.*

a = size(adjmat);
stream = api.Plex4.createExplicitSimplexStream();

for i = 1:a(1)
    stream.addVertex(i);
end
for i = 1:a(1)
    for j = i:a(1)
        if adjmat(i,j) == 1
            stream.addElement([i,j]);
        end
    end
end
for i = 1:a(1)
    for j = i:a(1)
        for k = j:a(1)
            if adjmat(i,j) == 1 && adjmat(i,k) == 1 && adjmat(j,k) == 1
                stream.addElement([i,j,k]);
            end
        end
    end
end
% for i = 1:a(1)
%     for j = i:a(1)
%         for k = j:a(1)
%             for l = k:a(1)
%                 if adjmat(i,j) == 1 && adjmat(i,k) == 1 && adjmat(j,k) == 1 && adjmat(i,l) == 1 && adjmat(j,l) == 1 && adjmat(k,l) == 1
%                     stream.addElement([i,j,k,l]);
%                 end
%             end
%         end
%     end
% end
% for i = 1:a(1)
%     for j = i:a(1)
%         for k = j:a(1)
%             for l = k:a(1)
%                 for m= l:a(1)
%                     if adjmat(i,j) == 1 && adjmat(i,k) == 1 && adjmat(j,k) == 1 && adjmat(i,l) == 1 && adjmat(j,l) == 1 && adjmat(k,l) == 1 && adjmat(i,m) == 1 && adjmat(j,m) == 1 && adjmat(k,m) == 1 && adjmat(l,m) == 1
%                         stream.addElement([i,j,k,l,m]);
%                     end
%                 end
%             end
%         end
%     end
% end
% for i = 1:a(1)
%     for j = i:a(1)
%         for k = j:a(1)
%             for l = k:a(1)
%                 for m= l:a(1)
%                     for n= m:a(1)
%                         if adjmat(i,j) == 1 && adjmat(i,k) == 1 && adjmat(j,k) == 1 && adjmat(i,l) == 1 && adjmat(j,l) == 1 && adjmat(k,l) == 1 && adjmat(i,m) == 1 && adjmat(j,m) == 1 && adjmat(k,m) == 1 && adjmat(l,m) == 1 && adjmat(i,n) == 1 && adjmat(j,n) == 1 && adjmat(k,n) == 1 && adjmat(l,n) == 1 && adjmat(m,n) == 1 
%                             stream.addElement([i,j,k,l,m,n]);
%                         end
%                     end
%                 end
%             end
%         end
%     end
% end

stream.finalizeStream();
end