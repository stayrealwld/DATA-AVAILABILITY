function [ r ] = ArrayofSimplices(stream,k)
%ARRAYOFSIMPLICES 此处显示有关此函数的摘要
%   此处显示详细说明
import edu.stanford.math.plex4.*;
% print out the total number of simplices in the complex
%size_stream = stream.getSize()

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%n=0;
r=[];


iterator = stream.iterator();
while (iterator.hasNext())
    % the next line will print the current simplex
    simplex = iterator.next();
    % here you can do whatever is needed with the simplex
    %filtration_value = stream.getFiltrationValue(simplex);
    %aa=length(simplex.toString())
    %bb=simplex.toString()%bb转化为string
    cc=simplex.getVertices;%将simplex变为matlab可识别的数组

    kk=length(cc);
    if k==kk
        %n=n+1;          %n = Number_of_k_simplices(stream,k);
        r=[r; cc'];      %r = ArrayofSimplices(stream,k);
    end

end

end

