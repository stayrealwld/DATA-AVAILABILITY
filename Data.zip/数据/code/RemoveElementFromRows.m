function new_triangle = RemoveElementFromRows(triangle, a)
    % 创建一个新的空矩阵
    new_triangle = [];

    % 循环遍历每一行
    for i = 1:size(triangle, 1)
        % 使用逻辑索引选择不等于 a 的元素
        row_without_a = triangle(i, triangle(i, :) ~= a);
        new_triangle = [new_triangle; row_without_a];
    end
end




