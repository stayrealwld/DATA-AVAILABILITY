output = node_removal_sc(A,data,triangles);
outputeff = efficiency_sc(A,data,triangles);



