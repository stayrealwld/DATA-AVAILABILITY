function modified_A = modify_matrix(A, a, b)
    n_rows_a = size(a, 1);
    n_rows_b = size(b, 1);
    modified_A = A;
    counts = zeros(n_rows_a, 1);

    for row_a = 1:n_rows_a
        exit_outer_loop = false; % 标志变量，用于指示是否跳出外部循环
        for row_b = 1:n_rows_b
            if ismember(a(row_a, 1), b(row_b, :)) && ismember(a(row_a, 2), b(row_b, :))
                counts(row_a) = counts(row_a) + 1;
                if counts(row_a) > 1
                    % 如果任一对元素在 b 中出现超过一次，设置标志变量
                    exit_outer_loop = true;
                    break; % 跳出内部循环
                end
            end
        end
        
        if exit_outer_loop
            continue; % 跳过当前外部循环的迭代，继续下一个 row_a
        end
    end

    
    for row_a = 1:n_rows_a
        if counts(row_a) == 1
            idx_a_1 = a(row_a, 1);
            idx_a_2 = a(row_a, 2);
            modified_A(idx_a_1, idx_a_2) = 0;
            modified_A(idx_a_2, idx_a_1) = 0;
        end
    end
end
