
function output = node_removal_sc(A,data,triangles)
%     A = readmatrix("ajinchukou.csv");
    n = length(A);
    num_iterations = size(data, 2);
    output = zeros(n+1, num_iterations);
    
    A0 = A;
    col_index = 0;
    for iter = 1:num_iterations
        A_temp = A0;
        all = data(:, iter);
        col_index = col_index + 1;
        steps = 1; % 切换到下一个列的索引位置
        output(steps, col_index)=1;
        i = 1;
        while i <= n-1 % i 是删除的节点数目
            % 如果A_temp(all(i), :)和A_temp(:, all(i))都已经为0，则跳过本次迭代
            if ~any(A_temp(all(i), :)) && ~any(A_temp(:, all(i)))
                i = i + 1;
                continue;
            end
            steps = steps + 1;
            A_temp(all(i), :) = 0;
            A_temp(:, all(i)) = 0;
            triangles_with_i = triangles(any(triangles == all(i), 2), :);
            remove_i=RemoveElementFromRows(triangles_with_i, all(i));
            A_temp = modify_matrix(A_temp, remove_i, triangles);

            detect = Detect_largest_connected_component(A_temp);
            if ~isempty(detect)
                stream = flag_Simplicial_Complex_from_Adjacency_Matrix(detect);
                a = ArrayofSimplices(stream, 3);
                if ~isempty(a)
                    tri = intersect(a, triangles, 'rows');
                    triangles = tri;
                end
                output(steps, col_index) = sum(any(detect, 2)) / n;
            else
                output(steps, col_index) = 0;
                break;
            end
            A_temp = detect;
            i = i + 1;
        end
    end
end


